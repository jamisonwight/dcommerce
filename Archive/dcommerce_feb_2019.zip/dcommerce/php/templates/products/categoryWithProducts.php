<div class="grid-x custom-category-with-products">
    <div class="cell ecp-component ecp_CategoryWithProducts">
        <div class="grid-x">
            <h1 class="cell">{message:category_name}</h1>
            <p class="cell medium-10 medium-offset-1">{message:display_html}</p>
        </div>
        <div id="products" class="grid-x grid-margin-x grid-padding-x grid-margin-y grid-padding-y ecp-x-list" data-ecp-handle="products" data-slug="{message:category_name}">
            <!-- | CategoryWithProducts__Product template | -->
        </div>
    </div>
</div>