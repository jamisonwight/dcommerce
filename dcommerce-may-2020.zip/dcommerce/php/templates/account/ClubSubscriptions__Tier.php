<div>
  <h4>{message:club_tier_name}</h4>
  <div class="ecp-html-content" data-ecp-handle="custom_tier_info">{message:ClubSubscriptions/CustomTierInfo}</div>
  <div data-ecp-handle="subscriptions">
    <!-- 
      | ClubSubscriptions__Subscription__Shipment template |
      or
      | ClubSubscriptions__Subscription__Pickup template |
      -->
  </div>
</div>