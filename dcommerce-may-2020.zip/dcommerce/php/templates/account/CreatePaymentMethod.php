<div class="grid-x ecp-component account ecp_CreatePaymentMethod">
    <div class="cell medium-8 medium-offset-2">
        <h1>{message:CreatePaymentMethod/Title}</h1>
        <p class="ecp-summary">{message:CreatePaymentMethod/Summary}</p>
        <div data-ecp-handle="payform_wrapper">
            <!-- | OEPayform template | -->
        </div>
    </div>
    <div class="cell medium-8 medium-offset-2">
        <a href="/store/?view=account">< Back to Account</a>
    </div>
</div>