<div class="grid-x ecp-component ecp_ReplacePaymentMethod">
    <div class="cell medium-8 medium-offset-2">
        <h1>{message:ReplacePaymentMethod/Title}</h1>
        <p class="ecp-summary">{message:ReplacePaymentMethod/Summary}</p>
        <div data-ecp-handle="payform_wrapper">
            <!-- | OEPayform template | -->
        </div>
    </div>
</div>