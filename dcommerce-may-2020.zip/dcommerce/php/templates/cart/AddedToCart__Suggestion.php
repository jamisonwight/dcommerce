<li data-ecp-id="{message:product_id} {message:css_class}">
  <a href="{message:__productdetail_link}" data-ecp-action="load-product" data-ecp-key="{message:slug}">
    <img src="{message:thumbnail}" alt="{message:AddedToCart/ImageAlt_template}">
    <div>{message:product_name}</div>
  </a>
</li>