<div class="grid-x account">
	<div class="cell medium-8 medium-offset-2 ecp-component ecp_JoinClub">
	  <h2>{message:JoinClub/Title}</h2>
	  <div class="ecp-html-content">{message:JoinClub/SummaryHTML}</div>
	  <form class="ecp-form">
	    <button data-ecp-action="show-tiers">{message:JoinClub/ShowTiersButton}</button>
	  </form>
	</div>
</div>