<div class="grid-x account">
	<div class="cell medium-8 medium-offset-2 ecp-component ecp_ClubSubscriptionThankYou">
	  <h1>{message:ClubSubscriptionThankYou/Title_template}</h1>
	  <div class="ecp-html-content">{message:ClubSubscriptionThankYou/SummaryHTML_template}</div>
	  <ul class="ecp-item-list">
	    <li><a href="#" data-ecp-action="manage-account">{message:ClubSubscriptionThankYou/ManageAccountLink}</a></li>
	    <li><a href="#" data-ecp-action="join-club">{message:ClubSubscriptionThankYou/JoinClubLink}</a></li>
	  </ul>
	</div>
</div>