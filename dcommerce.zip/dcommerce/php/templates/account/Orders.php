<div class="grid-x ecp-component ecp_Orders">
  <form class="ecp-form cell medium-8 medium-offset-2">
    <h1>{message:Orders/Title}</h1>
    <p class="ecp-summary">{message:Orders/Summary}</p>
    <div class="ecp-x-list" data-ecp-handle="orders">
      <!-- | Orders__Order template | -->
    </div>
    <button class="ecp-secondary" data-ecp-action="load-dashboard">{message:Orders/HomeButton}</button>
  </form>
</div>