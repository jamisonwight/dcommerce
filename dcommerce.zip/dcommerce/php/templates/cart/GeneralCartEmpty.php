<div class="grid-x grid-padding-y cart cart_EmptyCart">
    <div class="cell ecp-component ecp_GeneralCartEmpty">
        <h1>{message:GeneralCartEmpty/Title}</h1>
        <p class="ecp-summary">{message:GeneralCartEmpty/Summary}</p>
        <a href="/store/?view=products&slug=CurrentReleases"><button>{message:GeneralCartEmpty/ActionButton}</button></a>
    </div>
</div>