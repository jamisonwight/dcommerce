<div class="cart cart_Minicart">
    <div class="ecp-component ecp_MiniCart">
        <a href="{message:__cart_link}" data-ecp-action="load-cart">
            <span data-ecp-handle="0_items">Cart  <span class="cartCount">0</span></span>
            <span data-ecp-handle="1_item">Cart 
                <span class="cartCount">{message:MiniCart/OneItem_template}</span>
            </span>
            <span data-ecp-handle="n_items">Cart
                <span class="cartCount">{message:MiniCart/MultipleItems_template}</span>
            </span>
        </a>
    </div>
</div>
