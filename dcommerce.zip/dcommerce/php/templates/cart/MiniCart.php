<div class="cart cart_Minicart">
    <div class="ecp-component ecp_MiniCart">
        <a href="{message:__cart_link}" data-ecp-action="load-cart">
            <span class="fa fa-shopping-cart" aria-hidden="true"></span>
            <span data-ecp-handle="0_items">{message:MiniCart/NoItems_template}</span>
            <span data-ecp-handle="1_item">{message:MiniCart/OneItem_template}</span>
            <span data-ecp-handle="n_items">{message:MiniCart/MultipleItems_template}</span>
        </a>
    </div>
</div>
