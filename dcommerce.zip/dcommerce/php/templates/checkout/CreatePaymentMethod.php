<div class="grid-x ecp-component ecp_CreatePaymentMethod--checkout">
    <div class="cell small-10 small-offset-1 large-8 large-offset-2">
        <h1>{message:CreatePaymentMethod/Title}</h1>
        <div data-ecp-handle="progress_bar">
            <!-- | Checkout__ProgressBar template | -->
        </div>
        <p class="ecp-summary">{message:CreatePaymentMethod/Summary}</p>
        <div data-ecp-handle="payform_wrapper">
            <!-- | OEPayform template | -->
        </div>
    </div>
</div>