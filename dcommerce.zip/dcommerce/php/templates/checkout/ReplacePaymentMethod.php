<div class="grid-x ecp-component ecp_ReplacePaymentMethod--checkout">
    <h1>{message:ReplacePaymentMethod/Title}</h1>
    <div data-ecp-handle="progress_bar">
        <!-- | Checkout__ProgressBar template | -->
    </div>
    <p class="ecp-summary">{message:ReplacePaymentMethod/Summary}</p>
    <div data-ecp-handle="payform_wrapper">
        <!-- | OEPayform template | -->
    </div>
</div>