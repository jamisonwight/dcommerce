<div class="login-presence">
    <div class="ecp-component ecp_Presence">
        <a href="{message:__login_link}" data-ecp-action="login" data-ecp-handle="login">{message:Presence/Login}</a>
        <a href="{message:__logout_link}" data-ecp-action="logout" data-ecp-handle="logout">Logout</a>
    </div>
</div>