<div id="products" class="ecp-x-list" data-ecp-handle="products">
    <!-- | CategoryWithProducts__Product template | -->
</div>