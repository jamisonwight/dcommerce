<div class="grid-x signup">
    <div class="ecp-component ecp_CreateCustomerThankYou">
        <h2>{message:CreateCustomerThankYou/Title}</h2>
        <div class="ecp-html-content">{message:CreateCustomerThankYou/ThankYouHTML}</div>
        <ul class="ecp-item-list">
            <li><a href="#" data-ecp-action="manage-account">{message:CreateCustomerThankYou/ManageAccountLink}</a></li>
            <li><a href="#" data-ecp-action="shop">{message:CreateCustomerThankYou/ShopLink}</a></li>
        </ul>
    </div>
</div>