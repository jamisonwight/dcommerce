<div class="grid-x ecp-component ecp_JoinClub">
    <div class="cell medium-8 medium-offset-2">
        <h1>{message:JoinClub/Title}</h1>
        <div class="ecp-html-content">{message:JoinClub/SummaryHTML}</div>
        <form class="ecp-form">
            <button data-ecp-action="show-tiers">{message:JoinClub/ShowTiersButton}</button>
        </form>
    </div>
</div>