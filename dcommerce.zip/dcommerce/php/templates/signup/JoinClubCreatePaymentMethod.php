<div class="grid-x ecp-component ecp_JoinClub__CreatePaymentMethod">
    <div class="cell medium-8 medium-offset-2">
        <h1>{message:club_tier_name}</h1>
        <div data-ecp-handle="progress_bar">
            <!-- | JoinClub__ProgressBar template | -->
        </div>
        <p class="ecp-summary">{message:JoinClub/CreatePaymentMethod/Summary}</p>
        <div data-ecp-handle="payform_wrapper">
            <!-- | OEPayform template | -->
        </div>
    </div>
</div>