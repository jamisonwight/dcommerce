<div class="grid-x ecp-component ecp_JoinClub__SelectTier">
    <div class="cell medium-8 medium-offset-2">
        <h1>{message:JoinClub/SelectTier/Title}</h1>
        <div data-ecp-handle="progress_bar"></div>
        <div class="ecp-html-content">{message:JoinClub/SelectTier/SummaryHTML}</div>
        <form class="ecp-form">
            <div class="ecp-x-list" data-ecp-handle="tiers">
            <!-- | JoinClubSelectTier__Tier template | -->
            </div>
        </form>
    </div>
</div>